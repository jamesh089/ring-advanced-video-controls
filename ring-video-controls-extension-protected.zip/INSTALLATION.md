# Quick Installation Guide

## Step-by-Step Installation

### 1. Download the Extension Files
Make sure you have all the following files in a folder:
- `manifest.json`
- `content.js`
- `styles.css`
- `README.md`

### 2. Generate Icons (Optional)
1. Open `create_icons.html` in your browser
2. Right-click each canvas and "Save image as":
   - Save as `icon16.png` (16x16)
   - Save as `icon48.png` (48x48)
   - Save as `icon128.png` (128x128)

### 3. Load Extension in Chrome
1. Open Chrome browser
2. Navigate to `chrome://extensions/`
3. Enable "Developer mode" (toggle in top-right corner)
4. Click "Load unpacked"
5. Select the folder containing your extension files
6. The extension should now appear in your extensions list

### 4. Test the Extension
1. Navigate to any Ring.com page
2. Look for the "Video Controls" panel in the top-right corner
3. Adjust the sliders to modify video appearance
4. Use the "Reset" button to restore default values

### 5. Alternative Testing
You can also test the extension locally by:
1. Opening `test.html` in your browser
2. The control panel should appear and work with the test video

## Troubleshooting

**Extension not loading:**
- Check that all required files are present
- Ensure manifest.json is valid JSON
- Check Chrome's extension page for error messages

**Controls not appearing on Ring.com:**
- Verify the extension is enabled
- Refresh the Ring.com page
- Check browser console for errors

**Video not responding to controls:**
- The extension only works with `<video>` elements
- Some video players use different technologies
- Check if the video is in an iframe (may not be accessible)

## File Requirements

Minimum required files for the extension to work:
- ✅ `manifest.json` - Extension configuration
- ✅ `content.js` - Main functionality
- ✅ `styles.css` - Visual styling

Optional files:
- `icon16.png`, `icon48.png`, `icon128.png` - Extension icons
- `README.md` - Documentation
- `test.html` - Testing page 