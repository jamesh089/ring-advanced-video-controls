# Ring Video Controls Chrome Extension

A Chrome extension that adds video control capabilities to Ring.com live video pages, allowing users to adjust zoom, color filters, and apply noise reduction effects.

## Features

- **Zoom Control**: Scale video from 50% to 300%
- **Brightness Adjustment**: Adjust brightness from 0% to 200%
- **Contrast Control**: Modify contrast from 0% to 200%
- **Hue Rotation**: Rotate hue from -180° to +180°
- **Saturation Control**: Adjust saturation from 0% to 200%
- **Noise Reduction**: Apply blur filter from 0px to 10px for noise reduction
- **Reset Function**: One-click reset to restore default values
- **Real-time Updates**: Changes apply immediately as you adjust sliders
- **Responsive Design**: Works on desktop and mobile devices

## Installation

### Method 1: Load as Unpacked Extension (Recommended for Development)

1. Download or clone this repository to your local machine
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" by toggling the switch in the top-right corner
4. Click "Load unpacked" and select the folder containing the extension files
5. The extension will now be installed and active

### Method 2: Create Extension Package

1. Zip all the extension files (manifest.json, content.js, styles.css, and icons)
2. Rename the .zip file to .crx (optional)
3. Drag and drop the .crx file into Chrome's extensions page

## Usage

1. Navigate to any Ring.com page (the extension only activates on ring.com domains)
2. Look for the "Video Controls" panel in the top-right corner of the page
3. Adjust the sliders to modify video appearance:
   - **Zoom**: Scale the video larger or smaller
   - **Brightness**: Make the video brighter or darker
   - **Contrast**: Increase or decrease contrast
   - **Hue**: Shift colors around the color wheel
   - **Saturation**: Make colors more or less vivid
   - **Noise Reduction**: Apply blur to reduce video noise
4. Click the "Reset" button to restore all values to default

## File Structure

```
ring-video-controls-extension/
├── manifest.json      # Extension manifest (Manifest V3)
├── content.js         # Content script that injects controls
├── styles.css         # CSS styles for the control panel
├── icon16.png         # 16x16 extension icon
├── icon48.png         # 48x48 extension icon
├── icon128.png        # 128x128 extension icon
└── README.md          # This file
```

## Technical Details

- **Manifest Version**: 3 (latest Chrome extension standard)
- **Permissions**: Only requires `activeTab` permission
- **Host Permissions**: Limited to `https://ring.com/*`
- **Content Scripts**: Automatically injects on ring.com pages
- **No External Dependencies**: Pure vanilla JavaScript and CSS

## Browser Compatibility

- Chrome 88+ (Manifest V3 support required)
- Edge 88+ (Chromium-based)
- Other Chromium-based browsers

## Development

### Making Changes

1. Edit the files as needed
2. Go to `chrome://extensions/`
3. Click the refresh icon on the extension card
4. Reload the Ring.com page to see changes

### Debugging

- Open Chrome DevTools on a Ring.com page
- Check the Console tab for extension logs
- Use the Elements tab to inspect the injected control panel

## Troubleshooting

**Extension not appearing on Ring.com:**
- Ensure the extension is enabled in Chrome extensions page
- Check that you're on a ring.com domain
- Refresh the page after enabling the extension

**Controls not affecting video:**
- The extension looks for `<video>` elements on the page
- Some video players use iframes which may not be accessible
- Check browser console for any error messages

**Performance issues:**
- The extension uses CSS filters which are hardware-accelerated
- If experiencing lag, try reducing the number of active filters

## License

This project is open source and available under the MIT License.

## Contributing

Feel free to submit issues, feature requests, or pull requests to improve the extension.

## Changelog

### Version 1.0.0
- Initial release
- Basic video controls (zoom, brightness, contrast, hue, saturation, blur)
- Reset functionality
- Responsive design
- Manifest V3 compliance 